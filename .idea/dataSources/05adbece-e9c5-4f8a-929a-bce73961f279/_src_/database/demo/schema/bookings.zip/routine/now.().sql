create function bookings.now() returns timestamp with time zone
LANGUAGE SQL
AS $$
SELECT '2016-10-13 17:00:00'::TIMESTAMP AT TIME ZONE 'Europe/Moscow';
$$;
