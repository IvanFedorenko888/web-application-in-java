CREATE VIEW flights_v AS SELECT f.flight_id,
    f.flight_no,
    f.scheduled_departure,
    timezone(dep.timezone, f.scheduled_departure) AS scheduled_departure_local,
    f.scheduled_arrival,
    timezone(arr.timezone, f.scheduled_arrival) AS scheduled_arrival_local,
    (f.scheduled_arrival - f.scheduled_departure) AS scheduled_duration,
    f.departure_airport,
    dep.airport_name AS departure_airport_name,
    dep.city AS departure_city,
    f.arrival_airport,
    arr.airport_name AS arrival_airport_name,
    arr.city AS arrival_city,
    f.status,
    f.aircraft_code,
    f.actual_departure,
    timezone(dep.timezone, f.actual_departure) AS actual_departure_local,
    f.actual_arrival,
    timezone(arr.timezone, f.actual_arrival) AS actual_arrival_local,
    (f.actual_arrival - f.actual_departure) AS actual_duration
   FROM bookings.flights f,
    bookings.airports dep,
    bookings.airports arr
  WHERE ((f.departure_airport = dep.airport_code) AND (f.arrival_airport = arr.airport_code));
COMMENT ON VIEW bookings.flights_v IS 'Рейсы';
COMMENT ON COLUMN bookings.flights_v.flight_id IS 'Идентификатор рейса';
COMMENT ON COLUMN bookings.flights_v.flight_no IS 'Номер рейса';
COMMENT ON COLUMN bookings.flights_v.scheduled_departure IS 'Время вылета по расписанию';
COMMENT ON COLUMN bookings.flights_v.scheduled_departure_local IS 'Время вылета по расписанию, местное время в пункте отправления';
COMMENT ON COLUMN bookings.flights_v.scheduled_arrival IS 'Время прилёта по расписанию';
COMMENT ON COLUMN bookings.flights_v.scheduled_arrival_local IS 'Время прилёта по расписанию, местное время в пункте прибытия';
COMMENT ON COLUMN bookings.flights_v.scheduled_duration IS 'Планируемая продолжительность полета';
COMMENT ON COLUMN bookings.flights_v.departure_airport IS 'Код аэропорта отправления';
COMMENT ON COLUMN bookings.flights_v.departure_airport_name IS 'Название аэропорта отправления';
COMMENT ON COLUMN bookings.flights_v.departure_city IS 'Город отправления';
COMMENT ON COLUMN bookings.flights_v.arrival_airport IS 'Код аэропорта прибытия';
COMMENT ON COLUMN bookings.flights_v.arrival_airport_name IS 'Название аэропорта прибытия';
COMMENT ON COLUMN bookings.flights_v.arrival_city IS 'Город прибытия';
COMMENT ON COLUMN bookings.flights_v.status IS 'Статус рейса';
COMMENT ON COLUMN bookings.flights_v.aircraft_code IS 'Код самолета, IATA';
COMMENT ON COLUMN bookings.flights_v.actual_departure IS 'Фактическое время вылета';
COMMENT ON COLUMN bookings.flights_v.actual_departure_local IS 'Фактическое время вылета, местное время в пункте отправления';
COMMENT ON COLUMN bookings.flights_v.actual_arrival IS 'Фактическое время прилёта';
COMMENT ON COLUMN bookings.flights_v.actual_arrival_local IS 'Фактическое время прилёта, местное время в пункте прибытия';
COMMENT ON COLUMN bookings.flights_v.actual_duration IS 'Фактическая продолжительность полета';
